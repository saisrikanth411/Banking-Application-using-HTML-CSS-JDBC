import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.sql.*;
import java.util.Scanner;

@WebServlet("/Update")
public class Update extends javax.servlet.
  http.HttpServlet implements javax.servlet.Servlet {
  static final long serialVersionUID = 1L;
   
  public Update () {
    super();
  }   	
	
  protected void doGet(HttpServletRequest request, 
    HttpServletResponse response)throws ServletException, IOException {
	  PrintWriter out = response.getWriter();

	  
	  try
	  {
		  String name = request.getParameter("name");
		 int c_ssn = Integer.parseInt(request.getParameter("c_ssn"));
		 String sorry = "Updated Customer";
		 int aptno = Integer.parseInt(request.getParameter("aptno"));
		    int streetno = Integer.parseInt(request.getParameter("streetno"));
		    String city = request.getParameter("city");
		    String state = request.getParameter("state");
		    int zip = Integer.parseInt(request.getParameter("zip"));
		    
		    try {
		    	Class.forName("com.mysql.jdbc.Driver").newInstance();

		    	Connection con = DriverManager.getConnection(
		    	  "jdbc:mysql://localhost:3306/bestbank?user=root&password=root");
		    	Statement stmt = con.createStatement();
		    	
		    	 
		    	
		    	ResultSet rs = stmt.executeQuery("select * from customer;");
		    	while(rs.next())
		    	{
		    		if(rs.getInt(1) == c_ssn)
		    		{
		    		stmt.execute("update customer set aptno = "+aptno+" where C_SSN = "+c_ssn+"");
		    		stmt.execute("update customer set streetno = "+streetno+" where C_SSN = "+c_ssn+"");
		    		stmt.execute("update customer set city = '"+city+"' where C_SSN = "+c_ssn+"");
		    		stmt.execute("update customer set state = '"+state+"' where C_SSN = "+c_ssn+"");
		    		stmt.execute("update customer set zip = "+zip+" where C_SSN = "+c_ssn+"");
		    			
		    		out.println("<html>\n" +
							"<head></head>\n" +
								            "<body bgcolor=\"#fff5e6\">\n" +
								            "<h1 align=\"center\">" + sorry + " "+ name + "</h1>\n" +
								            
								            "</body></html>");
		    		}
		    		else
		    		{
		    			out.println("<html>\n" +
				 				"<head></head>\n" +
				 					            "<body bgcolor=\"#0066ff\r\n" + 
				 					            "\">\n" +"<center>"+
				 					           "<h1 align=\"center\">Wrong Credentials</h1>\n"+
				 					            "</body></html>");
			    	
		    	}
		    	}
		    	
				    
		    	
		    	
		    }
		    catch(Exception u)
		    {
		    	u.printStackTrace();
		    }
		    
	  }
	  catch(Exception e)
	  {
		  e.printStackTrace();
	  }
	  
  }
  
}