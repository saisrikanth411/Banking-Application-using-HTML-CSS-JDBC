import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.sql.*;
import java.util.Scanner;

@WebServlet("/Passbook")
public class Passbook extends javax.servlet.
  http.HttpServlet implements javax.servlet.Servlet {
  static final long serialVersionUID = 1L;
   
  public Passbook () {
    super();
  }   	
	
  protected void doGet(HttpServletRequest request, 
    HttpServletResponse response)throws ServletException, IOException {
	  PrintWriter out = response.getWriter();
	  
	  String welcome = "Welcome";
		 try {
	    String name = request.getParameter("username");
	    int accno = Integer.parseInt(request.getParameter("accountno"));
	  int c_ssn = Integer.parseInt(request.getParameter("c_ssn"));
	    try {
	    	Class.forName("com.mysql.jdbc.Driver").newInstance();

	    	Connection con = DriverManager.getConnection(
	    	  "jdbc:mysql://localhost:3306/bestbank?user=root&password=root");
	    	Statement stmt = con.createStatement();
	    	
	    	 ResultSet rr = stmt.executeQuery("select * from has_account where C_SSN = "+c_ssn+"");
			    while(rr.next())
			    {
			    if(rr.getInt(1) == c_ssn && rr.getInt(2) == accno)	
			    {
	    	
	    	String t_name;
	    	
	    	
	    	int amount1;
	    	int amount2;
	    	int balance;
	    	
	    	out.println("<html>\n" +
	    				"<head></head>\n" +
	    					            "<body bgcolor=\"rgb(255, 213, 116)\"\n" +
	    					 	    					            "\">\n" +"<center>"
	    					         
	    					            +"</center>"+
	    					            "<table border= 5;style=\"width:100%\">"+
	    					            
	    					            
 		 " <tr>"+
 		    "<th>Date</th>"+
 		    "<th>Transaction Code</th>"+
 		    "<th>Transaction Name</th>"+
 		    "<th>Debits</th>"+
 		    "<th>Credits</th>"+
 		    "<th>Balance</th>"+
 		  "</tr>");
	    	
	    	
	    	ResultSet rs = stmt.executeQuery("select Balance from account where Account_No = '"+accno+"';");
	    	while(rs.next())
	    	{
	    		balance = rs.getInt(1);
	    		
	    		ResultSet r1 = stmt.executeQuery("select * from transaction where Account_No = '"+accno+"';");
	    		while(r1.next())
	    		{
	    			if(r1.getString(6).equals("WD"))
	    			{
	    				t_name = r1.getString(6);
	    			amount1 = r1.getInt(5);
	    			amount2= 0;
	    			balance = balance - amount1;
	    			System.out.println(balance);
	    			//stmt.execute("update account set Balance = '"+balance+"' - '"+amount1+"';");
	    			System.out.println("ok");
	    			out.println(  "<tr>"+
		     		    "<td>&nbsp&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;"+r1.getDate(3)+"</td>"+
		     		    "<td>&nbsp&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;"+r1.getString(6)+"</td>"+
		     		    "<td>&nbsp&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;"+t_name+"</td>"+
		     		    "<td>&nbsp&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;"+amount1+"</td>"+
		     		    "<td>&nbsp&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;"+amount2+"</td>"+
		     		    "<td>&nbsp&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;"+balance+"</td>"+
		     		    
		     		  "</tr>"+
		 	    					            "</body></html>");
	    			
	    			
	    			}
	    			else if(r1.getString(6).contentEquals("CD"))
	    			{
	    				t_name = r1.getString(6);
	    				amount1 = 0;
	    				amount2 = r1.getInt(5);
	    				balance = balance + amount2;
	    				System.out.println(balance);
	    				System.out.println("okay");
	    				
	    				out.println(  "<tr>"+
	    		     		    "<td>&nbsp&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;"+r1.getDate(3)+"</td>"+
	    		     		    "<td>&nbsp&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;"+r1.getString(6)+"</td>"+
	    		     		    "<td>&nbsp&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;"+t_name+"</td>"+
	    		     		    "<td>&nbsp&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;"+amount1+"</td>"+
	    		     		    "<td>&nbsp&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;"+amount2+"</td>"+
	    		     		    "<td>&nbsp&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;"+balance+"</td>"+
	    		     		    
	    		     		  "</tr>"+
	    		 	    					            "</body></html>");
	    				
	    			}
	    		}
	    		r1.close();
	    		
	    		
	    		
	    	}
			    }
			    else
			    {
			    	out.println("<html>\n" +
			 				"<head></head>\n" +
			 					            "<body bgcolor=\"#0066ff\r\n" + 
			 					            "\">\n" +"<center>"+
			 					           "<h1 align=\"center\">Wrong Credentials</h1>\n"+
			 					            "</body></html>");
			    }
			    }
	    	
	    }
	    
	    
	    
	    catch(Exception e)
	    {
	    	
	    }
		 }
		 catch(Exception u)
		 {
			 
		 }
  }
}
	    		
	    		