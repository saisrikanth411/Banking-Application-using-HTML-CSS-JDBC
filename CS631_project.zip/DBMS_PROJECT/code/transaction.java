import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.sql.*;
import java.util.Scanner;

@WebServlet("/transaction")
public class transaction extends javax.servlet.
  http.HttpServlet implements javax.servlet.Servlet {
  static final long serialVersionUID = 1L;
   
  public transaction () {
    super();
  }   	
	
  protected void doGet(HttpServletRequest request, 
    HttpServletResponse response)throws ServletException, IOException {
	  PrintWriter out = response.getWriter();

	  
	  try
	  {
		  String name = request.getParameter("username");
		    int account_send = Integer.parseInt(request.getParameter("accno1"));
		    
		    int account_recieve = Integer.parseInt(request.getParameter("accno2"));
		    
		    int c_ssn = Integer.parseInt(request.getParameter("c_ssn"));
		    
		    String b_name_send = request.getParameter("b_name_send");
		    String b_name_recieve = request.getParameter("b_name_recieve");
		    int amount = Integer.parseInt(request.getParameter("amount"));
		   
		    try {
		    	Class.forName("com.mysql.jdbc.Driver").newInstance();

		    	Connection con = DriverManager.getConnection(
		    	  "jdbc:mysql://localhost:3306/bestbank?user=root&password=root");
		    	Statement stmt = con.createStatement();
		    ResultSet rr = stmt.executeQuery("select * from has_account where C_SSN = "+c_ssn+"");
		    while(rr.next())
		    {
		    if(rr.getInt(1) == c_ssn && rr.getInt(2) == account_send)	
		    {
		    	
		 ResultSet rs = stmt.executeQuery("select * from account where Account_No = '"+account_send+"';");
		 
		 if(rs.next())
		 {
			 if(amount < rs.getInt(4))
			 {
				 String p = "update account set Balance = Balance - "+amount+" where Account_No = '"+account_send+"'";  
		    		stmt.execute(p);
		    		
		    		String r = "update branch set assets = assets - "+amount+" where B_name = '"+b_name_send+"'";
				    stmt.execute(r);
				    
				    String b = "update account set Last_access = CURDATE() where Account_No = '"+account_send+"'";
				    stmt.execute(b);
				    
				    System.out.println("okay");
			 }
		 }
		 rs.close();
		 
		 ResultSet r1 = stmt.executeQuery("select * from account where Account_No = '"+account_recieve+"';");
		 
		 if(r1.next())
		 {
			 if(amount < r1.getInt(4))
			 {
				 String p = "update account set Balance = Balance + "+amount+" where Account_No = '"+account_recieve+"'";  
		    		stmt.execute(p);
		    		
		    		String r = "update branch set assets = assets + "+amount+" where B_name = '"+b_name_recieve+"'";
				    stmt.execute(r);
				    
				    String b = "update account set Last_access = CURDATE() where Account_No = '"+account_recieve+"'";
				    stmt.execute(b);
				    
				    System.out.println("okay");
			 }
		 }
		 r1.close();
		int amt = 2;
		 /*
		 stmt.execute("set GLOBAL event_scheduler=ON;");
		 stmt.execute("CREATE EVENT service_charge");
		    stmt.execute("ON SCHEDULE EVERY 1 MONTH STARTS '2010-05-01 00:00:00' ");
		    
		    stmt.execute("DO");
		    stmt.execute("update account set Balance = Balance - amt");
		    stmt.execute("insert into transaction values ()
		 */
		 
		 
		 ResultSet r2 = stmt.executeQuery( "select MAX(Record_no) from transaction;");
		 if(r2.next())
		 {
			 int count = r2.getInt(1);
		    	count++;
		    	String a = "insert into transaction values('"+count+"','"+account_send+"', CURDATE(), CURTIME(),'"+amount+"','WD')";
	    		stmt.execute(a);
	    		
	    		
	    		stmt.execute("set GLOBAL event_scheduler=ON;");
	    		stmt.execute("DROP EVENT service;");
	    		String serv = "CREATE EVENT service ON SCHEDULE EVERY 1 MONTH STARTS '2010-05-01 00:00:00' DO update account set Balance = Balance - amt ";
	   		 stmt.execute(serv);
	   		 
	   		 stmt.execute("DROP EVENT trans");
	   		 String trans = "create event trans on schedule every 1 month starts '2010-05-01 00:00:00' do  insert into transaction values ('"+count+"','"+account_send+"',CURDATE(),CURTIME(),'"+amt+"','SC')";
	   		 
	   		 
	   		 stmt.execute(trans);
	   		 
	   		String charge = "update charge set amt = amt + 2 where B_Name = '"+account_send+"'";
	   		 stmt.execute(charge);
	    		//stmt.execute("CREATE EVENT service_charge ON SCHEDULE EVERY 1 MONTH STARTS '2010-05-01 00:00:00' DO update account set Balance = Balance - amt AND insert into transaction values ('"+count+"','"+account_send+"',CURDATE(),CURTIME(),'"+amt+"','SC')");
	   		    //stmt.execute("ON SCHEDULE EVERY 1 MONTH STARTS '2010-05-01 00:00:00' ");
	   		   
	   		    /*
	   		    stmt.execute("DO");
	   		    stmt.execute("update account set Balance = Balance - amt");
	   		   // stmt.execute("insert into transaction values ('"+count+"','"+account_send+"',CURDATE(),CURTIME(),'"+amt+"','SC'");
	   		    stmt.execute("END$$;");
	   		  */
	   		System.out.println("okay1");
		 }
		 
		 r2.close();
		 
		 ResultSet r3 = stmt.executeQuery( "select MAX(Record_no) from transaction;");
		 if(r3.next())
		 {
			 int count = r3.getInt(1);
		    	count++;
		    	String a = "insert into transaction values('"+count+"','"+account_recieve+"', CURDATE(), CURTIME(),'"+amount+"','CD')";
	    		stmt.execute(a);
	    		System.out.println("okay2");
		 }
		 r3.close();
		 
		 
		 out.println("<html>\n" +
 				"<head></head>\n" +
 					            "<body bgcolor=\"#0066ff\r\n" + 
 					            "\">\n" +"<center>"
 					           +"<h1>Amount Withdrawn is  "+amount+"</h1>"
 					           +"<h1>Account Debited  is  "+account_send+"</h1>"
 					           +"<h1>Account Credited  is  "+account_recieve+"</h1>"
 					            +"</center>"+
 					            "</body></html>");
		 
		 
		 
		 
		    }
		    else
		    {
		    	out.println("<html>\n" +
		 				"<head></head>\n" +
		 					            "<body bgcolor=\"#0066ff\r\n" + 
		 					            "\">\n" +"<center>"+
		 					           "<h1 align=\"center\">Wrong Credentials</h1>\n"+
		 					            "</body></html>");
		    }
		    }
	  }
		    catch(Exception u)
		    {
		    	u.printStackTrace();
		    }
	  }
	  catch(Exception e)
	  {
		  e.printStackTrace();
		  
	  }
	  

}
}