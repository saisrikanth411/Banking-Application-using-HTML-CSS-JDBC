import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.sql.*;
import java.util.Scanner;

@WebServlet("/Main")
public class Main extends javax.servlet.
  http.HttpServlet implements javax.servlet.Servlet {
  static final long serialVersionUID = 1L;
   
  public Main () {
    super();
  }   	
	
  protected void doGet(HttpServletRequest request, 
    HttpServletResponse response)throws ServletException, IOException {
	  PrintWriter out = response.getWriter();
	  String welcome = "Welcome";
	 try {
    String name = request.getParameter("name");
    int c_ssn = Integer.parseInt(request.getParameter("c_ssn"));
    int e_ssn;
    String b_name = request.getParameter("b_name");
    String role = request.getParameter("role");
    int aptno = Integer.parseInt(request.getParameter("aptno"));
    int streetno = Integer.parseInt(request.getParameter("streetno"));
    String city = request.getParameter("city");
    String state = request.getParameter("state");
    int zip = Integer.parseInt(request.getParameter("zip"));
	 
	
    
    try {
	Class.forName("com.mysql.jdbc.Driver").newInstance();

	Connection con = DriverManager.getConnection(
	  "jdbc:mysql://localhost:3306/bestbank?user=root&password=root");
	Statement stmt = con.createStatement();
	//stmt.executeQuery("SET FOREIGN_KEY_CHECKS = 0");
	ResultSet r =stmt.executeQuery("select e.e_ssn from employee as e join customer as c where c.e_ssn = e.e_ssn and c.B_Name = '"+b_name+"';");
	if(r.next())
	{
	 e_ssn = r.getInt(1);
	 r.close();
	
	String s = "Insert into customer values('"+c_ssn+"' ,'"+e_ssn+"' ,'"+b_name+"' , '"+name+"' ,  '"+aptno+"' ,'"+streetno+"' ,'"+city+"' ,'"+state+"' ,'"+zip+"' , '"+role+"')";      
	//if(name != null)
	  stmt.execute(s);
	ResultSet rs = stmt.executeQuery("Select name from customer");
	if(rs.next())
	{
		/*
		out.println("<html>\n" +
				"<head></head>\n" +
					            "<body bgcolor=\"#fff5e6\">\n" +
					            "<h1 align=\"center\">" + welcome + " "+ name + "</h1>\n" +
					            
					            "</body></html>");
					            */
		response.sendRedirect("deposit.jsp");
	}
	rs.close();
	}
	
    } catch (Exception ex) {
	System.out.println(ex);
	System.exit(0);
    }
	 }
	 catch(Exception e)
	 {
		 
	 }
    System.out.println("Program terminated with no error.");
  }  	
  
	
  protected void doPost(HttpServletRequest request, 
    HttpServletResponse response)throws ServletException, IOException {
    // TODO Auto-generated method stub
  }   	  	    
}
