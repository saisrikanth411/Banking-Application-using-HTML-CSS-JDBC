import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.sql.*;
import java.util.Scanner;

@WebServlet("/DeleteCust")
public class DeleteCust extends javax.servlet.
  http.HttpServlet implements javax.servlet.Servlet {
  static final long serialVersionUID = 1L;
   
  public DeleteCust () {
    super();
  }   	
	
  protected void doGet(HttpServletRequest request, 
    HttpServletResponse response)throws ServletException, IOException {
	  PrintWriter out = response.getWriter();

	  
	  try
	  {
		  String name = request.getParameter("username");
		    int accountno = Integer.parseInt(request.getParameter("accountno"));
		    int c_ssn = Integer.parseInt(request.getParameter("c_ssn"));
		    
		    
		    String sorry = "Deleted Customer ";
		    
		    try {
		    	Class.forName("com.mysql.jdbc.Driver").newInstance();

		    	Connection con = DriverManager.getConnection(
		    	  "jdbc:mysql://localhost:3306/bestbank?user=root&password=root");
		    	Statement stmt = con.createStatement();
		    	
		    	//stmt.execute("SET FOREIGN_KEY_CHECKS=0;");
		    	
		    	ResultSet r1 = stmt.executeQuery("select * from account where Account_No = '"+accountno+"';");
				 
				 if(r1.next())
				 {
					 
						 
				    		String r = "update branch set assets = assets - "+r1.getInt(4)+" where B_Name = '"+r1.getString(2)+"'";
						    stmt.execute(r);
						    
						    
						    
						    System.out.println("okay");
					 
				 }
				 r1.close();
		    	
		    	
		    	
		    	
		    	
		    	ResultSet rs = stmt.executeQuery("select Loan_No from has_loan where C_SSN = '"+c_ssn+"';");
		    	if(rs.next())
		    	{
		    		stmt.execute("delete from has_loan where c_ssn = '"+c_ssn+"';");
		    		//stmt.execute("delete from loan where Loan_no = '"+rs.getInt(1)+"';");
		    		//int loan_no = rs.getInt(1);
		    		//stmt.execute("delete from loan where Loan_no = '"+loan_no+"';");
		    		
		    	}
		    	rs.close();
				
		    	
		    	
		    	ResultSet r2 = stmt.executeQuery("select * from checking;");
		    	while(r2.next())
		    	{
		    		if(r2.getInt(1) == accountno)
		    		{
		    			stmt.execute("delete from checking where Account_No = '"+accountno+"';");
		    		}
		    		else
		    		{
		    			System.out.println("no checking account");
		    		}
		    	}
		    	r2.close();
		    	
		    	ResultSet r3 = stmt.executeQuery("select * from savings;");
		    	while(r3.next())
		    	{
		    		if(r3.getInt(1) == accountno)
		    		{
		    			stmt.execute("delete from savings where Account_No = '"+accountno+"';");
		    			
		    		}
		    		else
		    		{
		    			System.out.println("no savings account");
		    		}
		    	}
		    	r3.close();
		    	
		    	
		    	stmt.execute("delete from transaction where Account_No = '"+accountno+"';");
		    	//stmt.execute("delete from checking where Account_No = '"+accountno+"';");
		    	//stmt.execute("delete from savings where Account_No = '"+accountno+"';");
		    	stmt.execute("delete from has_account where Account_No = '"+accountno+"';");
		    	stmt.execute("delete from customer where C_SSN = '"+c_ssn+"';");
		    	stmt.execute("delete from account where Account_No = '"+accountno+"';");
		    	//stmt.execute("delete from loan where )
		    	
		    	
		    
		    	out.println("<html>\n" +
						"<head></head>\n" +
							            "<body bgcolor=\"#fff5e6\">\n" +
							            "<h1 align=\"center\">" + sorry + " "+ name + "</h1>\n" +
							            
							            "</body></html>");
		    	
		    	
		    }
		    catch(Exception u)
		    {
		    	u.printStackTrace();
		    }
		    
		    
		    
	  }
	  catch(Exception e)
	  {
		  e.printStackTrace();
	  }
  }
}