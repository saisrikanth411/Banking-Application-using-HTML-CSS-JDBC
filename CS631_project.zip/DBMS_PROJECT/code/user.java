import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.sql.*;
import java.util.Scanner;

@WebServlet("/user")
public class user extends javax.servlet.
  http.HttpServlet implements javax.servlet.Servlet {
  static final long serialVersionUID = 1L;
   
  public user () {
    super();
  }   	
	
  protected void doGet(HttpServletRequest request, 
    HttpServletResponse response)throws ServletException, IOException {
	  PrintWriter out = response.getWriter();
	  
	  String user = request.getParameter("username");
	  int c_ssn = Integer.parseInt(request.getParameter("password"));
	  
	  try {
	    	Class.forName("com.mysql.jdbc.Driver").newInstance();

	    	Connection con = DriverManager.getConnection(
	    	  "jdbc:mysql://localhost:3306/bestbank?user=root&password=root");
	    	Statement stmt = con.createStatement();
	    	
	    	String s = "select name,C_SSN from customer where c_ssn = '"+c_ssn+"' and  name = '"+user+"'" ;
	    	
	    			ResultSet rs = stmt.executeQuery(s);
	    			
	    			while(rs.next())
	    			{
	    				if(user.equals(rs.getString(1)) && c_ssn == rs.getInt(2))
	    				{
	    					response.sendRedirect("user.html");
	    				}
	    				else
	    				{
	    					System.out.println("wrong user");
	    				}
	    			}
	    			
	    	
	    	
	  }
	  catch(Exception e)
	  {
		  e.printStackTrace();
	  }
	  
	  
}
}