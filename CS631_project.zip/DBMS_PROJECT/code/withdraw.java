import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.sql.*;
import java.util.Scanner;
import java.util.*;

@WebServlet("/withdraw")
public class withdraw extends javax.servlet.
  http.HttpServlet implements javax.servlet.Servlet {
  static final long serialVersionUID = 1L;
   
  public withdraw () {
    super();
  }   	
	
  protected void doGet(HttpServletRequest request, 
    HttpServletResponse response)throws ServletException, IOException {
	  PrintWriter out = response.getWriter();

	  try
	  {
		  String name = request.getParameter("username");
		    int accountno = Integer.parseInt(request.getParameter("accno"));
		    int c_ssn = Integer.parseInt(request.getParameter("c_ssn"));
		    String b_name = request.getParameter("b_name");
		    int amount = Integer.parseInt(request.getParameter("amount"));
		    int count; 
		   
		   		    try {
		    	Class.forName("com.mysql.jdbc.Driver").newInstance();

		    	Connection con = DriverManager.getConnection(
		    	  "jdbc:mysql://localhost:3306/bestbank?user=root&password=root");
		    	Statement stmt = con.createStatement();
		    	
		    	 ResultSet rr = stmt.executeQuery("select * from has_account where C_SSN = "+c_ssn+"");
				    while(rr.next())
				    {
				    if(rr.getInt(1) == c_ssn && rr.getInt(2) == accountno)	
				    {
		    	
		    	
		    	
		    	ResultSet r3 = stmt.executeQuery( "select MAX(Record_no) from transaction;");
				 if(r3.next())
				 {
					  count = r3.getInt(1);
				    	count++;
				 
				 r3.close();
		    	
		  
		    	
		    String s = "select Balance from account where Account_No = '"+accountno+"';";
		    ResultSet rs = stmt.executeQuery(s);
		    if(rs.next())
		    {
		    	if(amount <= rs.getInt(1))
		    	{
		    		
		    		String p = "update account set Balance = Balance - "+amount+" where Account_No = '"+accountno+"'";  
		    		stmt.execute(p);
		    		String r = "update branch set assets = assets - "+amount+" where B_name = '"+b_name+"'";
				    stmt.execute(r);
				    
				    String b = "update account set Last_access = CURDATE() where Account_No = '"+accountno+"'";
				    stmt.execute(b);
				    
				    String a = "insert into transaction values('"+count+"','"+accountno+"', CURDATE(), CURTIME(),'"+amount+"','WD')";
		    		stmt.execute(a);
				    
				    
				    out.println("<html>\n" +
		    				"<head></head>\n" +
		    					            "<body bgcolor=\"#0066ff\r\n" + 
		    					            "\">\n" +"<center>"
		    					           +"<h1>Amount Withdrawn is  "+amount+"</h1>"
		    					            +"</center>"+
		    					            "</body></html>");
				    
		    	}
		    	else
		    	{
		    		out.println("<html>\n" +
		    				"<head></head>\n" +
		    					            "<body bgcolor=\"#0066ff\r\n" + 
		    					            "\">\n" +"<center>"
		    					           +"<h1>Insufficient Balance </h1>"
		    					            +"</center>"+
		    					            "</body></html>");
		    	}
		    }
		    	
		    rs.close();
				 }
				 r3.close();
		    System.out.println("okay");
		    
		    
		    	
		    	}
				    else
				    {
				    	out.println("<html>\n" +
				 				"<head></head>\n" +
				 					            "<body bgcolor=\"#0066ff\r\n" + 
				 					            "\">\n" +"<center>"+
				 					           "<h1 align=\"center\">Wrong Credentials</h1>\n"+
				 					            "</body></html>");
				    }
				    }
		   		    }
				    
		    catch(Exception u)
		    {
		    	u.printStackTrace();
		    	System.out.println("not okay");
		    }
	  
	  }	  
	  
	  catch(Exception e)
	  {
		  e.printStackTrace();
	  }

}
}
